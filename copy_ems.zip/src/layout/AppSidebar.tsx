import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom"; // ✅ CORRECT IMPORT

import {
  BookIcon,
  CalendarIcon,
  // CalendarIcon,
  CapIcon,
  ChatIcon,
  // ChartIcon,
  FileIcon,
  GraphIcon,
  // GraphIcon,
  GridIcon,
  GroupIcon,
  MonitorIcon,
  SetingsIcon,
} from "../icons";
import { useSidebar } from "../context/SidebarContext";

type NavItem = {
  name: string;
  icon: React.ReactNode;
  path?: string;
  subItems?: { name: string; path: string; pro?: boolean; new?: boolean }[];
};

const AppSidebar: React.FC = () => {
  const { isExpanded, isMobileOpen, isHovered, setIsHovered } = useSidebar();
  const location = useLocation(); // ✅ CORRECT HOOK

  // Get user role from localStorage
  const [userRole, setUserRole] = useState<string>('faculty');

  useEffect(() => {
    const role = localStorage.getItem('role') || 'faculty';
    setUserRole(role);
  }, []);

  const facultyNavItems: NavItem[] = [
    {
      icon: <GridIcon />,
      name: "Dashboard",
      path: "/",
    },
    {
      icon: <FileIcon />,
      name: "Question Generator",
      path: "/question-generator",
    },
    {
      icon: <BookIcon />,
      name: "Exam Management",
      path: "/exam-management",
    },
    {
      icon: <CapIcon />,
      name: "Grading",
      path: "/grading",
    },
    {
      icon: <GroupIcon />,
      name: "Student Management",
      path: "/student-management",
    },
  ];

  const adminNavItems: NavItem[] = [
    {
      icon: <GridIcon />,
      name: "Dashboard",
      path: "/admin-dashboard",
    },
    {
      icon: <GraphIcon />,
      name: "Analytics",
      path: "/analytics",
    },
    {
      icon: <FileIcon />,
      name: "Audit Log",
      path: "/audit-log",
    },
    {
      icon: <BookIcon />,
      name: "Knowledge Base",
      path: "/knowledge-base",
    },
    {
      icon: <SetingsIcon />,
      name: "Paper Format",
      path: "/paper-format",
    },
    {
      icon: <MonitorIcon />,
      name: "System Format",
      path: "/system-format",
    },
  ];


  const StudentNavItems: NavItem[] = [
    {
      icon: <GridIcon />,
      name: "Dashboard",
      path: "/student-dashboard",
    },
    {
      icon: <CalendarIcon />,
      name: "Upcoming Exams",
      path: "/upcoming-exams",
    },
    {
      icon: <BookIcon />,
      name: "All Exams",
      path: "/exams",
    },
    {
      icon: <GraphIcon />,
      name: "Result & Analytics",
      path: "/result-analytics",
    },
    {
      icon: <ChatIcon />,
      name: "AI Study Assistant",
      path: "/ai-assistant",
    }
  ];

  const navMap = {
    Admin: adminNavItems,
    Faculty: facultyNavItems,
    Student: StudentNavItems
  };

  const currentNavItems = navMap[userRole as keyof typeof navMap] || [];


  const [openSubmenu, setOpenSubmenu] = useState<{
    type: "main" | "settings" | "others";
    index: number;
  } | null>(null);

  const [subMenuHeight, setSubMenuHeight] = useState<Record<string, number>>({});
  const subMenuRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const isActive = useCallback(
    (path: string) => location.pathname === path, // ✅ now uses useLocation
    [location.pathname]
  );

  useEffect(() => {
    let submenuMatched = false;

    currentNavItems.forEach((nav, index) => {
      if (nav.subItems) {
        nav.subItems.forEach((subItem) => {
          if (isActive(subItem.path)) {
            setOpenSubmenu({
              type: "main",
              index,
            });
            submenuMatched = true;
          }
        });
      }
    });

    if (!submenuMatched) {
      setOpenSubmenu(null);
    }
  }, [location, isActive, currentNavItems]);

  useEffect(() => {
    if (openSubmenu !== null) {
      const key = `${openSubmenu.type}-${openSubmenu.index}`;
      if (subMenuRefs.current[key]) {
        setSubMenuHeight((prevHeights) => ({
          ...prevHeights,
          [key]: subMenuRefs.current[key]?.scrollHeight || 0,
        }));
      }
    }
  }, [openSubmenu]);

  const handleSubmenuToggle = (
    index: number,
    menuType: "main" | "settings" | "others"
  ) => {
    setOpenSubmenu((prev) =>
      prev && prev.type === menuType && prev.index === index
        ? null
        : { type: menuType, index }
    );
  };

  const renderMenuItems = (
    items: NavItem[],
    menuType: "main" | "settings" | "others"
  ) => (
    <ul className="flex flex-col gap-4">
      {items.map((nav, index) => (
        <li key={nav.name}>
          {nav.subItems ? (
            <button
              onClick={() => handleSubmenuToggle(index, menuType)}
              className={`menu-item group ${openSubmenu?.type === menuType && openSubmenu?.index === index
                  ? "menu-item-active"
                  : "menu-item-inactive"
                } cursor-pointer ${!isExpanded && !isHovered ? "lg:justify-center" : "lg:justify-start"
                }`}
            >
              <span
                className={`menu-item-icon-size ${openSubmenu?.type === menuType && openSubmenu?.index === index
                    ? "menu-item-icon-active"
                    : "menu-item-icon-inactive"
                  }`}
              >
                {nav.icon}
              </span>
              {(isExpanded || isHovered || isMobileOpen) && (
                <span className="menu-item-text">{nav.name}</span>
              )}
            </button>
          ) : (
            nav.path && (
              <Link
                to={nav.path}
                className={`menu-item group ${isActive(nav.path)
                    ? "menu-item-active"
                    : "menu-item-inactive"
                  }`}
              >
                <span
                  className={`menu-item-icon-size ${isActive(nav.path)
                      ? "menu-item-icon-active"
                      : "menu-item-icon-inactive"
                    }`}
                >
                  {nav.icon}
                </span>
                {(isExpanded || isHovered || isMobileOpen) && (
                  <span className="menu-item-text">{nav.name}</span>
                )}
              </Link>
            )
          )}

          {nav.subItems && (isExpanded || isHovered || isMobileOpen) && (
            <div
              ref={(el) => {
                subMenuRefs.current[`${menuType}-${index}`] = el;
              }}
              className="overflow-hidden transition-all duration-300"
              style={{
                height:
                  openSubmenu?.type === menuType &&
                    openSubmenu?.index === index
                    ? `${subMenuHeight[`${menuType}-${index}`]}px`
                    : "0px",
              }}
            >
              <ul className="mt-2 space-y-1 ml-9">
                {nav.subItems.map((subItem) => (
                  <li key={subItem.name}>
                    <Link
                      to={subItem.path}
                      className={`menu-dropdown-item ${isActive(subItem.path)
                          ? "menu-dropdown-item-active"
                          : "menu-dropdown-item-inactive"
                        }`}
                    >
                      {subItem.name}
                      <span className="flex items-center gap-1 ml-auto">
                        {subItem.new && (
                          <span
                            className={`ml-auto ${isActive(subItem.path)
                                ? "menu-dropdown-badge-active"
                                : "menu-dropdown-badge-inactive"
                              } menu-dropdown-badge`}
                          >
                            new
                          </span>
                        )}
                        {subItem.pro && (
                          <span
                            className={`ml-auto ${isActive(subItem.path)
                                ? "menu-dropdown-badge-active"
                                : "menu-dropdown-badge-inactive"
                              } menu-dropdown-badge`}
                          >
                            pro
                          </span>
                        )}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </li>
      ))}
    </ul>
  );

  return (
    <aside
      className={`fixed mt-16 flex flex-col lg:mt-0 top-0 px-5 left-0 bg-white dark:bg-gray-900 dark:border-gray-800 text-gray-900 h-screen transition-all duration-300 ease-in-out z-50 border-r border-gray-200 
        ${isExpanded || isMobileOpen
          ? "w-[240px]"
          : isHovered
            ? "w-[240px]"
            : "w-[90px]"
        }
        ${isMobileOpen ? "translate-x-0" : "-translate-x-full"}
        lg:translate-x-0`}
      onMouseEnter={() => !isExpanded && setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className={`py-8 flex ${!isExpanded && !isHovered ? "lg:justify-center" : "justify-start"
          }`}
      >
        <Link to="/">
          {isExpanded || isHovered || isMobileOpen ? (
            <>
              <img
                className="dark:hidden"
                src="/images/logo/logo.svg"
                alt="Logo"
                width={150}
                height={40}
              />
              <img
                className="hidden dark:block"
                src="/images/logo/logo-dark.svg"
                alt="Logo"
                width={150}
                height={40}
              />
            </>
          ) : (
            <img
              src="/images/logo/logo-icon.svg"
              alt="Logo"
              width={32}
              height={32}
            />
          )}
        </Link>
      </div>
      <div className="flex flex-col flex-grow overflow-y-auto duration-300 ease-linear no-scrollbar">
        <nav className="mb-6 flex-grow">
          <div className="flex flex-col gap-4">
            <div>{renderMenuItems(currentNavItems, "main")}</div>
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default AppSidebar;
